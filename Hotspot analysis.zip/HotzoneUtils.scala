package cse512

object HotzoneUtils {

  /**
   * Checks whether pointString lies within queryRectangle or not
   *
   * Definition:
   *
   * You first need to parse the pointString
   * (e.g., "-88.331492,32.324142") and queryRectangle
   * (e.g., "-155.940114,19.081331,-155.618917,19.5307") to a format
   * that you are comfortable with. Then check whether the queryRectangle
   * fully contains the point. Consider on-boundary point.
   *
   * @param queryRectangle
   * @param pointString
   * @return
   */
  def ST_Contains(queryRectangle: String, pointString: String): Boolean = {
    val rectangleTokens = queryRectangle.split(",")
    val x1 = rectangleTokens(0).trim.toDouble
    val y1 = rectangleTokens(1).trim.toDouble
    val x2 = rectangleTokens(2).trim.toDouble
    val y2 = rectangleTokens(3).trim.toDouble

    val pointTokens = pointString.split(",")
    val x = pointTokens(0).trim.toDouble
    val y = pointTokens(1).trim.toDouble

    val x_top = math.min(x1, x2)
    val x_bottom = math.max(x1, x2)
    val y_top = math.min(y1, y2)
    val y_bottom = math.max(y1, y2)

    if (x < x_top ||
      x > x_bottom ||
      y < y_top ||
      y > y_bottom)
      false
    else true
  }

}
